import java.util.Iterator;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] array;
    private int size;

    public RandomizedQueue(){
        size = 0 ;
        array = (Item[]) new Object[10];

    }                 // construct an empty randomized queue
    public boolean isEmpty(){
        return size == 0;
    }                 // is the randomized queue empty?
    public int size(){
        return  size;
    }                        // return the number of items on the randomized queue
    public void enqueue(Item item){
        if(item == null){
            throw new java.lang.IllegalArgumentException();
        }
        array[size++] = item;
        if (size == array.length){
            resize(array.length * 2);
        }
    }           // add the item
    public Item dequeue(){
        if (size == 0){
            throw new java.util.NoSuchElementException();
        }
        StdRandom.shuffle(array);
        Item item = array[size];
        array[size] = null;
        size --;
        if (size >  0&& size < array.length/4){
            resize(array.length/2);
        }
        return item;
    }                    // remove and return a random item
    public Item sample(){
        if (size == 0){
            throw new java.util.NoSuchElementException();
        }
        int id = StdRandom.uniform(size);
        return array[id];
    }
    // return a random item (but do not remove it)
    private void resize(int capacity){
        Item[] temp = (Item[]) new Object[capacity];
        for (int i = 0; i < size; i++) {
            temp[i] = array[i];
        }
        array = temp;
    }
    public Iterator<Item> iterator(){
        return new RandomizedQueueIterator();
    }
    // return an independent iterator over items in random order

    private class RandomizedQueueIterator implements Iterator<Item>{
        public Item next(){
            if (size == 0){
                throw new java.util.NoSuchElementException();
            }
            StdRandom.shuffle(array);
            Item item = array[size];
            size --;
            return item;
        }
        public boolean hasNext(){
            return size > 0;
        }
        public void remove(){
            throw new java.lang.UnsupportedOperationException();
        }

    }
//    public static void main(String[] args)   // unit testing (optional)
}